Sites' data handler
===================
This program is designed for the specific purpose of handling  
different websites data such as: username & password  
run "python run.py --help" for the help menu.


Note: Running the program should be done in safe envoirment, i.e not vulnerable to possilbe  
backdoor breach.


<span style="color:RED">*WARNING*</span>.: THIS PROGRAM'S RANDOM GENERATED PASSWORDS UTILISE  
PSEUDO-RAINDOM ALGORITHMS.

_ *github@tutankhatum.com* _