from AES256 import AESCipher as AES
from hashlib import sha512
import time, os, re
import numpy as np
class Database:
    def __init__(self, key):
        if key==None:
            print("Error: A register key must be supplied")
            exit()
        self.keys = open("keys.db","r").read()
        if not sha512(key.encode()).hexdigest() in self.keys:
            print("Error: Incorrect/Unregistered key.")
            exit()
        else:
            self.key = key
        self.dbtemp = """
website: {site}
datestamp: {date}
username: {username}
password: {password}
------------------------\n
"""
        self.datetemp = "{hour}:{min}:{sec} {day}/{month}/{year}"
        self.charlib = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
        'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1',
        '2', '3', '4', '5', '6', '7', '8', '9', '~', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=', '+', '/']
        self.cipher = AES(self.key)
    def registerSite(self, site, username, password=None, randPass=False, N=False):
        if randPass:
            password = self.__generatePass(N)
        try:
            assert "<DirEntry 'sitesdata.db'>" in [str(entry) for entry in os.scandir()]
        except AssertionError:
            decision = input("Database file not found. Do you want to create a new one? (y/n) ")
            if decision=="y": pass
            elif decision=="n": exit()
            else: print("Error: unknown option."); exit()
        with open("sitesdata.db","a") as file:
            data = self.dbtemp.format(
                site = site, date = self.__getDate(), username = self.__encrypt(username), password = self.__encrypt(password)
            )
            file.write(data)
            file.close()
            print("Successful data site register!")
    def registerKey(self, key):
        try:
            assert "<DirEntry 'keys.db'>" in [str(entry) for entry in os.scandir()]
        except AssertionError:
            decision = input("Keys file not found. Do you want to create a new one? (y/n) ")
            if decision=="y": pass
            elif decision=="n": exit()
            else: print("Error: unknown option."); exit()
        with open("keys.db","a") as file:
            key = sha512(key.encode()).hexdigest()
            file.write(key)
            file.close()
            print("Successful key register!")
    def retrieve(self, site):
        with open("sitesdata.db","r") as file:
            file.seek(0)
            reader = file.read()
            file.close()
        try:
            siteSpan = self.__find("{site}".format(site = site))(reader).span()
        except:
            print("Error: site not found in the database.")
            exit()
        data = ''; Data=[]
        for i in range(siteSpan[0],len(reader)):
            if str(reader[i])!="-": data+=str(reader[i])
            else: break
        data = data.splitlines()
        for line in data:
            nwline=line.replace("website: ","").replace("username: ","").replace("datestamp: ","").replace("password: ","")
            Data.append(nwline)
        site = Data[0]
        date = Data[1]
        username = self.__decrypt(Data[2])
        password = self.__decrypt(Data[3])
        printable = self.dbtemp.format(
                site = site, date = date, username = username, password = password
            )
        return printable
    def __getDate(self):
        l = time.localtime()
        date = self.datetemp.format(
            year = l.tm_year, month = l.tm_mon, day = l.tm_mday,
            hour = l.tm_hour, min = l.tm_min, sec = l.tm_sec
        )
        return date
    def __find(self, word):
        match = re.compile(r'\b({0})\b'.format(word), flags=re.IGNORECASE).search
        return match
    def __encrypt(self, string):
        return self.cipher.enc(string).decode()
    def __decrypt(self, cipher):
        return self.cipher.dec(cipher)
    def __generatePass(self, length):
        password = ''
        for i in range(length):
            password += np.random.choice(self.charlib)
        return password
